import java.awt.*;
import java.net.URL;
import java.awt.Color;
import javax.swing.*;
import javax.swing.border.*;

public class TopFiveDestinationList {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
            	TopDestinationListFrame topDestinationListFrame = new TopDestinationListFrame();
                topDestinationListFrame.setTitle("Top 5 Destination List");
                topDestinationListFrame.setVisible(true);
                topDestinationListFrame.getContentPane().setBackground(Color.CYAN);
               
            }
        });
    }
}


class TopDestinationListFrame extends JFrame {
    private DefaultListModel listModel;

    public TopDestinationListFrame() {
        super("Top Five Destination List");

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(1000, 750);
        setBackground(Color.gray);

        listModel = new DefaultListModel();


        //Make updates to your top 5 list below. Import the new image files to resources directory.
        addDestinationNameAndPicture("1. Top Destination Dessert Scenery", 
        		new ImageIcon(getClass().getResource("/resources/TestImage.jpg")));
        ///////////////////////
        //I couldn't figure out a way to make a new line to add the photo credits.
        //I also ran into a lot of errors trying to add a URL click-able link
        // Most of URL in Java I found online had something to do with linking HTML <a> tags, but I couldn't get it to run
        ///////////////////////////////
		addDestinationNameAndPicture("2. 2nd Top Destination: Yosemite National Park, "
				+ " Image from New Indian Express by Medha Dutta Yadav.",
				new ImageIcon(getClass().getResource("/resources/YosemiteNationalPark.jpg ")));
        addDestinationNameAndPicture("3. 3rd Top Destination: Moonlight Cabins, " 
        		+ " Image from pexels.com by James Wheeler.", 
        		new ImageIcon(getClass().getResource("/resources/MoonLight.jpg")));
        addDestinationNameAndPicture("4. 4th Top Destination: Clift Cabins in Zurich, "
        		+ " Image from commons.wikimedia.org, by Daniel Kraft.", 
        		new ImageIcon(getClass().getResource("/resources/Glecksteinh�tte.jpg")));
        addDestinationNameAndPicture("5. 5th Top Destination: Clyburn Overlook Virgina, "
        		+ " Image from commons.wikimedia.org, by vastateparkstaff.", 
        		new ImageIcon(getClass().getResource("/resources/ClyburnOverlook.jpg")));

        JList list = new JList(listModel);
        JScrollPane scrollPane = new JScrollPane(list);
        TextAndIconListCellRenderer renderer = new TextAndIconListCellRenderer(2);
        list.setCellRenderer(renderer);
        //Setting background color to light gray makes it easier to read the text
        list.setBackground(Color.lightGray);
        //I keep thinking of this in terms of HTML, CSS and JavaScript.
        
        JLabel nameLabel = new JLabel ("Developer: Andrew Vue");
        getContentPane().add(nameLabel, BorderLayout.NORTH);
        getContentPane().add(scrollPane, BorderLayout.CENTER);
    }

    private void addDestinationNameAndPicture(String text, Icon icon) {
        TextAndIcon tai = new TextAndIcon(text, icon);
        listModel.addElement(tai);
    }
}


class TextAndIcon {
    private String text;
    private Icon icon;

    public TextAndIcon(String text, Icon icon) {
        this.text = text;
        this.icon = icon;
    }

    public String getText() {
        return text;
    }

    public Icon getIcon() {
        return icon;
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setIcon(Icon icon) {
        this.icon = icon;
    }
}

class TextAndIconListCellRenderer extends JLabel implements ListCellRenderer {
    private static final Border NO_FOCUS_BORDER = new EmptyBorder(10, 10, 10, 10);

    private Border insideBorder;

    public TextAndIconListCellRenderer() {
        this(10, 10, 10, 10);
    }

    public TextAndIconListCellRenderer(int padding) {
        this(padding, padding, padding, padding);
    }

    public TextAndIconListCellRenderer(int topPadding, int rightPadding, int bottomPadding, int leftPadding) {
        insideBorder = BorderFactory.createEmptyBorder(topPadding, leftPadding, bottomPadding, rightPadding);
        setOpaque(true);
    }

    public Component getListCellRendererComponent(JList list, Object value,
    int index, boolean isSelected, boolean hasFocus) {
        // The object from the combo box model MUST be a TextAndIcon.
        TextAndIcon tai = (TextAndIcon) value;

        // Sets text and icon on 'this' JLabel.
        setText(tai.getText());
        setIcon(tai.getIcon());

        if (isSelected) {
            setBackground(list.getSelectionBackground());
            setForeground(list.getSelectionForeground());
        } else {
            setBackground(list.getBackground());
            setForeground(list.getForeground());
        }

        Border outsideBorder;

        if (hasFocus) {
            outsideBorder = UIManager.getBorder("List.focusCellHighlightBorder");
        } else {
            outsideBorder = NO_FOCUS_BORDER;
        }

        setBorder(BorderFactory.createCompoundBorder(outsideBorder, insideBorder));
        setComponentOrientation(list.getComponentOrientation());
        setEnabled(list.isEnabled());
        setFont(list.getFont());

        return this;
    }

    // The following methods are overridden to be empty for performance
    // reasons. If you want to understand better why, please read:
    //
    // http://java.sun.com/javase/6/docs/api/javax/swing/DefaultListCellRenderer.html#override

    public void validate() {}
    public void invalidate() {}
    public void repaint() {}
    public void revalidate() {}
    public void repaint(long tm, int x, int y, int width, int height) {}
    public void repaint(Rectangle r) {}
}